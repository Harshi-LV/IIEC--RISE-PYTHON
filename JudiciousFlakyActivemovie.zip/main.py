<html>
<head>
<title>Linux APP </title>
</head>
<body id="grad1">
<style>
#grad1{
  height: 55px;
  background-color:red;
  background-image: linear-gradient(to right,red,orange,yellow,green,blue,violet);
}
</style>
<br>
<br>
<br>
<center><b><h2> !!WELLCOME TO THE LINUX COMMAND !! </h2></b>
<br>
<br>
<center><img src="https://logos-download.com/wp-content/uploads/2016/10/Red_Hat_logo_RedHat.png" width="350" height="100">
</center>
<center><b><h2> Enter the any command you want to run </h2></b>
</center>
<br>
<br>
<form action="http://192.168.0.105/cgi-bin/t2.py">
<h3>Your Command <input type ="text" name="c" required></h3>
<br>
<input type="submit">
</form>
</body>
</html>